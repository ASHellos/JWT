export const url=" http://localhost:3000"

export const loginBtn = document.getElementById("loginBtn");
export const emailLogin = document.getElementById("emailLogin");
export const passwordLogin = document.getElementById("passwordLogin");
export const welcomeElement = document.getElementById("welcomeElement");
export const applicationElement = document.getElementById("applicationElement");
export const loginElement = document.getElementById("loginElement");
export const registerElement = document.getElementById("registerElement");
export const memoInput = document.getElementById("memoInput");
export const resetBtn = document.getElementById("resetBtn");
export const addBtn = document.getElementById("addBtn");
export const tbody = document.getElementById("tbody");
export const emailRegister = document.getElementById("emailRegister");
export const nameRegister = document.getElementById("nameRegister");
export const passwordRegister = document.getElementById("passwordRegister");
export const passwordRegister2 = document.getElementById("passwordRegister2");
export const registerBtn = document.getElementById("registerBtn");
export const logoutElement = document.getElementById("logoutElement");
export const loading = document.getElementById("loading");
export const memoUpdate= document.getElementById("memoUpdate");


